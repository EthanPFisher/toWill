# Bash Commands

1. What is the command to create a file?

2. What is a command to create a folder?

3. What is the command to delete a file?

4. What is the command to delete a folder?

5. What is the command to move a file?

6. What is the command to copy a file?

7. What is the command to go up one directory?

8. What is the command to list the files in a directory?

9. What is the command to see what directory you are currently in?

10. What would typing `history` do?
